// Usage example: include this script in your public website to register token and send to backend
// Make sure to replace firebaseConfig fields and VAPID key.
import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.6.10/firebase-app.js';
import { getMessaging, getToken, onMessage } from 'https://www.gstatic.com/firebasejs/9.6.10/firebase-messaging.js';

const firebaseConfig = {
  apiKey: 'YOUR_API_KEY',
  authDomain: 'YOUR_PROJECT.firebaseapp.com',
  projectId: 'YOUR_PROJECT_ID',
  messagingSenderId: 'YOUR_SENDER_ID',
  appId: 'YOUR_APP_ID'
};

export async function enablePush(userId){
  const app = initializeApp(firebaseConfig);
  const messaging = getMessaging(app);
  try {
    const permission = await Notification.requestPermission();
    if (permission !== 'granted') throw new Error('Permission not granted');

    const token = await getToken(messaging, { vapidKey: 'YOUR_WEB_PUSH_CERT_KEY' });
    console.log('FCM Token', token);

    // send to your backend register endpoint
    await fetch('/register', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ userId, token }) });
    return token;
  } catch (e) {
    console.error('Push enable failed', e);
    throw e;
  }
}

export function handleForeground(messaging, onPayload){
  onMessage(messaging, payload => onPayload(payload));
}
